import { defineMessages } from 'react-intl';

export default defineMessages({
    msg: {
        err: 'Default Text, Check language files.'
    }
});